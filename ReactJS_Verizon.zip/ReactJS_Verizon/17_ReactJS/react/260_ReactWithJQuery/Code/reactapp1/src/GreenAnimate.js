import React from 'react';
import $ from 'jquery';

class GreenAnimate extends React.Component {
  constructor(props) {
    super(props);

    this.handleClick = this.handleClick.bind(this);
  }

  componentDidMount() {
    $('#greenbutton').click(() => {
      $('#greendiv').animate({
        height: 'toggle',
      });
    });
  }

  shouldComponentUpdate(nextProps, nextState) {
    // Take this component out of react's control. I.e. prevent re-rendering
    return false;
  }

  handleClick() {
    // Re-render this component on-demand.
    this.forceUpdate();
  }

  render() {
    return (
      <div>
        <button id="greenbutton" type="button">
          Animate
        </button>
        &nbsp;&nbsp;
        <button type="button" onClick={this.handleClick}>
          Force Update
        </button>
        <br />
        <br />
        <div
          id="greendiv"
          style={{
            background: 'green',
            color: 'white',
            height: 100,
            width: 200,
            position: 'relative',
          }}
        >
          {this.props.randomNumber}
        </div>
      </div>
    );
  }
}

export default GreenAnimate;
