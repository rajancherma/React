const sleep = ms => new Promise(resolve => setTimeout(resolve, ms));

const asyncValidate = values =>
  sleep(1000) // simulate server latency
    .then(() => {
      if (['sreekanthme@gmail.com.com', 'foo@foo.com'].includes(values.email)) {
        throw { email: 'Email already Exists' };
      }
    });

export default asyncValidate;
