const ws = "SreekanthME.com";
export default ws;
