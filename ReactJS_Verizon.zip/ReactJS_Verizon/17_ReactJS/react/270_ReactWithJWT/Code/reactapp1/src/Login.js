import React from "react";
import doAuth from "./Authenticate";
import { Redirect } from "react-router-dom";

class Login extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      redirectToReferrer: false,
      axios_message: ""
    };

    this.handleClick = this.handleClick.bind(this);
  }

  handleClick(ev) {
    ev.preventDefault();

    doAuth.authenticate(
      this.txtUsername.value,
      this.txtPassword.value,
      error => {
        if (!error) {
          this.setState({
            redirectToReferrer: true
          });
        } else {
          this.setState({
            redirectToReferrer: false,
            axios_message: error.response.data.message
          });
        }
      }
    );
  }

  render() {
    const { from } = this.props.location.state || { from: { pathname: "/" } };
    const { redirectToReferrer } = this.state;

    if (redirectToReferrer) {
      return <Redirect to={from} />;
    }

    return (
      <div>
        <p>You must log in to view the page at {from.pathname}</p>
        <form>
          Username:
          <input
            name="txtUsername"
            ref={node => {
              this.txtUsername = node;
            }}
            type="text"
          />
          <br />
          <br />
          Password:
          <input
            name="txtPassword"
            ref={node => {
              this.txtPassword = node;
            }}
            type="password"
          />
          <br />
          <br />
          HINT: Username: sreekanth, Password: test
          <br />
          <br />
          <button onClick={this.handleClick}>Log in</button>
          <h3> {this.state.axios_message}</h3>
        </form>
      </div>
    );
  }
}

export default Login;
