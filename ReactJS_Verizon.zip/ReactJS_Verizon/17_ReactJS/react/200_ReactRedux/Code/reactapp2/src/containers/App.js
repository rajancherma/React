import React from 'react';
import { connect } from 'react-redux';

class AppComponent extends React.Component {

  incrementCount(ev) {
    ev.preventDefault();
    this
      .props
      .dispatch({ type: 'INCR', payload: this.props.step });
  }

  decrementCounter(ev) {
    ev.preventDefault();
    this
      .props
      .dispatch({ type: 'DECR', payload: this.props.step });
  }

  resetState(ev) {
    ev.preventDefault();
    this
      .props
      .dispatch({ type: 'RESET_COUNT', payload: 0 });

    this
      .props
      .dispatch({ type: 'RESET_STEP', payload: 1 });
  }

  changeStep(ev) {
    const inputValue = ev.target.value;

    if (isNaN(inputValue) || (inputValue.length === 0)) {
      alert('Enter Integer Value.\n\n\n        Defaulting \'step\' to 1');
      this
        .props
        .dispatch({ type: 'CHANGE_STEP', payload: 1 });
      return;
    }

    const stepValue = Number.parseInt(ev.target.value, 10);

    this
      .props
      .dispatch({ type: 'CHANGE_STEP', payload: stepValue });
  }

  render() {
    return (
      <div>

        <form>
          <strong>{'Step: '}</strong>
          <input
            size="5"
            maxLength="3"
            type="text"
            value={this.props.step}
            onChange={this
            .changeStep
            .bind(this)} 
          /> {' '}

          <button onClick={this
            .resetState
            .bind(this)}
          >Reset</button>

          <br /><br />

          <button onClick={this
            .incrementCount
            .bind(this)}
          >Increment</button>

          {' '}

          <button onClick={this
            .decrementCounter
            .bind(this)}
          >Decrement</button>

        </form>

        <br /><br />
        <h1>Counter: {this.props.count}</h1>
        <h3>Step: {this.props.step}</h3>
      </div>
    );
  }
}

function mapStateToProps(state) {
  return { count: state.countReducer.count, step: state.stepReducer.step };
}

const App = connect(mapStateToProps)(AppComponent);

export { App };
