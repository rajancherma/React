import React from 'react';
import ReactDOM from 'react-dom';
import { Provider } from 'react-redux';
import { createStore } from 'redux';
import { App } from './containers/App';
import { AllReducers } from './reducers/combineReducers';

const storeCounter = createStore(AllReducers);

ReactDOM.render(
  <Provider store={storeCounter}><App /></Provider>, document.getElementById('root'));

// storeCounter.subscribe(() => console.log(storeCounter.getState()));

/*
Sample state:

{
  step: 1,
  count: 0
}
*/
