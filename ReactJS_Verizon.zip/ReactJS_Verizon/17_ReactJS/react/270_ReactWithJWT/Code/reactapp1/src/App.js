import React from "react";
import { BrowserRouter as Router, Route, Link } from "react-router-dom";
import AuthButton from "./AuthButton";
import Login from "./Login";
import PrivateRoute from "./PrivateRoute";
import MySkills from "./MySkills";

// 1. Click the public page
// 2. Click the protected page
// 3. Log in
// 4. Click the back button, note the URL each time

const App = () => (
  <Router>
    <div>
      <AuthButton />
      <ul>
        <li>
          <Link to="/public">Public Page</Link>
        </li>
        <li>
          <Link to="/protected1">Protected Page 1</Link>
        </li>
        <li>
          <Link to="/protected2">Protected Page 2</Link>
        </li>
        <li>
          <Link to="/myskills">My Skills</Link>
        </li>
      </ul>
      <hr />
      <Route path="/public" component={Public} />
      <Route path="/login" component={Login} />
      <PrivateRoute path="/protected1" component={Protected1} />
      <PrivateRoute path="/protected2" component={Protected2} />
      <PrivateRoute path="/myskills" component={MySkills} />
    </div>
  </Router>
);

const Public = () => <h3>This is the Public page</h3>;
const Protected1 = () => <h3>This is the Protected Page 1</h3>;
const Protected2 = () => <h3>This is the Protected Page 2</h3>;

export default App;
