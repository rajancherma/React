import React from 'react';
import GreenAnimate from './GreenAnimate';
import D3Component from './D3Component';

class App extends React.Component {
  constructor(props) {
    super(props);

    this.state = { random: Math.round(Math.random(10) * 100) };

    this.handleClick = this.handleClick.bind(this);
  }

  handleClick(ev) {
    ev.preventDefault();
    this.setState({ random: Math.round(Math.random() * 100) });
  }

  render() {
    return (
      <div>
        <form>
          <button type="button" onClick={this.handleClick}>
            Set State
          </button>
        </form>
        <h3>{this.state.random}</h3>
        <hr />

        <GreenAnimate randomNumber={this.state.random} />
        <hr />

        <D3Component randomNumber={this.state.random} />
        <hr />
      </div>
    );
  }
}

export default App;
