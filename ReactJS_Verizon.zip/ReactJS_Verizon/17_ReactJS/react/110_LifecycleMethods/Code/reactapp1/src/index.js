import React from 'react';
import ReactDOM from 'react-dom';
import ClockWithState from './App';

ReactDOM.render(
  <ClockWithState />, document.getElementById('app'));
