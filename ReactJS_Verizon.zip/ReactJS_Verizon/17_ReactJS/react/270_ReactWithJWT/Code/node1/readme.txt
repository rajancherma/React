1. **POST** the following JSON to http://localhost:3000/authenticate from POSTMAN
{
  "username": "sreekanth",
	"password": "test"
}

There will be a response similar to this:
{
    "token": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VybmFtZSI6InNyZWVrYW50aCIsInBhc3N3b3JkIjoiJDJhJDEwJEFibnFGc2R6MnVOZEUwdmdoT2x2YWVwdUJadmhVQ1VhaC9qVDFILjR1cC9CWFE4Z0NZR0xxIiwiaWF0IjoxNTExMjg0MDc0fQ.53qBVjkzZh-3fufscatBd7GIOnOA2hEc9AbPRmPaHrU"
}
---------------------------------------------------------------------
2. **GET** the URL: http://localhost:3000/protected withe the below to headers from POSTMAN:
  a. Authorization: Bearer <JWT Token>
  b. Content-Type: application/json
---------------------------------------------------------------------
NOTES:
=======
>> To start the app use the command: node app
>> To generate a new key, edit password in genpass.js and use the command: node genpass. Copy the password & generated password hash and paste it into the app.js.
>> CORS setting has to be made in Node.js program. Setting must allow posting of the header named "Authorization".
>> This piece of code is from: https://www.thepolyglotdeveloper.com/2017/03/jwt-authentication-in-a-node-js-powered-api/
>> An extra comma is being added by VS-code at line #29. Remove it from notepad.









