function stepReducer(state = {
  step: 1,
}, action) {
  switch (action.type) {
  case 'CHANGE_STEP':
    return {
        ...state,
        step: action.payload,
      };

  case 'RESET_STEP':
    return {
        ...state,
        step: 1,
      };

  default:
    return state;
  }
}

export { stepReducer };
