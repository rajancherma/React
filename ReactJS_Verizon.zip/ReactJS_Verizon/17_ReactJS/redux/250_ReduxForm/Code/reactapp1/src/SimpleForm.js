import React from "react";
import { Field, reduxForm } from "redux-form";
import submitSimple from "./SubmitSimple";

const validateForm = values => {
  const errors = {};
  if (!values.username) {
    errors.username = "Username is Required";
  } else if (values.username.length > 15) {
    errors.username = "Must be 15 characters or less";
  }
  if (!values.email) {
    errors.email = "Email is Required";
  } else if (!/^[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,4}$/i.test(values.email)) {
    errors.email = "Invalid email address";
  }
  if (!values.age) {
    errors.age = "Age is Required";
  } else if (isNaN(Number(values.age))) {
    errors.age = "Age Must be a number";
  } else if (Number(values.age) < 18) {
    errors.age = "Sorry, you must be at least 18 years old";
  }
  return errors;
};

const warnForm = values => {
  const warnings = {};
  if (values.age < 19) {
    warnings.age = "Hmm, you seem a bit young...";
  }
  return warnings;
};

const renderField = props => {
  const { input, name, label, type, meta } = props;

  return (
    <div>
      <label htmlFor={name}>
        {label}: &nbsp;
        <input {...input} placeholder={label} type={type} />
      </label>
      &nbsp;
      {meta.error ? (meta.touched ? meta.error : "") : ""}
      <br />
      <br />
      {console.log("meta: ", meta)}
    </div>
  );
};

const renderCheckbox = ({ input, label, type }) => (
  <div>
    {label}&nbsp;
    <input {...input} name={input.name} type={type} />
    <br />
    <br />
  </div>
);

const SimpleForm = props => {
  const { handleSubmit, reset, pristine, submitting, error } = props;
  return (
    <div>
      <h2>Registartion Form</h2>
      <form onSubmit={handleSubmit(submitSimple)}>
        <Field
          name="username"
          type="text"
          component={renderField}
          label="Username"
        />
        <Field
          name="email"
          type="email"
          component={renderField}
          label="Email"
        />
        <Field name="age" type="number" component={renderField} label="Age" />

        <Field
          name="employed"
          type="checkbox"
          component={renderCheckbox}
          label="Employed"
        />

        <div>{error || ""}</div>
        <div>
          <br />
          <button type="submit" disabled={submitting}>
            Submit
          </button>
          &nbsp;
          <button
            type="button"
            disabled={pristine || submitting}
            onClick={reset}
          >
            Clear Values
          </button>
        </div>
      </form>
    </div>
  );
};

//The config object must always have the key named "form"
const reduxSimpleForm = reduxForm({
  form: "simple",
  validate: validateForm,
  warn: warnForm
})(SimpleForm);

export default reduxSimpleForm;
