import React from "react";
import axios from "axios";

class MySkills extends React.Component {
  constructor(props) {
    super(props);

    this.state = {
      skills: ""
    };
  }

  componentDidMount() {
    axios
      .get("http://localhost:8080/protected_skills", {
        headers: {
          "Content-Type": "application/json",
          Authorization: "Bearer " + localStorage.getItem("jwToken")
        }
      })
      .then(response => {
        console.log("axios response: ", response.data);

        this.setState({ skills: response.data.skills });
      })
      .catch(error => {
        console.log("axios error.response: ", error.response);
      });
  }

  render() {
    return (
      <div>
        <strong>Web Skills:&nbsp;</strong> <br />
        {this.state.skills.web ? this.state.skills.web.join(", ") : ""}
        <br /> <br />
        <strong>Mobile Skills:&nbsp;</strong> <br />
        {this.state.skills.mobile ? this.state.skills.mobile.join(", ") : ""}
      </div>
    );
  }
}

export default MySkills;
