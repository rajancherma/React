const Express = require("express");
const BodyParser = require("body-parser");
const JsonWebToken = require("jsonwebtoken");
const Bcrypt = require("bcryptjs");

const app = Express();

app.use(BodyParser.json());

app.set("jwt-secret", "secretKeyCode");

const validateToken = function(request, response, next) {
  const authHeader = request.headers.authorization;

  if (authHeader) {
    const bearerToken = authHeader.split(" ");
    console.log("bearerToken: ", bearerToken);
    if (bearerToken.length == 2) {
      JsonWebToken.verify(
        bearerToken[1],
        app.get("jwt-secret"),
        (error, decodedToken) => {
          if (error) {
            return response
              .status(401)
              .send({ success: false, error: "Invalid authorization token" });
          }
          request.decodedToken = decodedToken;
          next();
        }
      );
    }
  } else {
    response
      .status(401)
      .send({ success: false, error: "An authorization header is required" });
  }
};

app.use(function(req, res, next) {
  res.header("Access-Control-Allow-Origin", "*");
  res.header(
    "Access-Control-Allow-Headers",
    "Origin, X-Requested-With, Content-Type, Accept, Authorization"
  );
  next();
});

app.post("/authenticate", (request, response) => {
  const user = {
    username: "sreekanth",
    password: "$2a$10$AbnqFsdz2uNdE0vghOlvaepuBZvhUCUah/jT1H.4up/BXQ8gCYGLq"
  };
  if (!request.body.username) {
    return response
      .status(401)
      .send({ success: false, message: "A `username` is required" });
  } else if (!request.body.password) {
    return response
      .status(401)
      .send({ success: false, message: "A `password` is required" });
  }
  Bcrypt.compare(request.body.password, user.password, (error, result) => {
    console.log("error: ", error);
    console.log("request.body.password: ", request.body.password);
    console.log("user.password: ", user.password);
    console.log("-------------------");

    if (error || !result) {
      return response
        .status(401)
        .send({ success: false, message: "Invalid username and password" });
    }
    const token = JsonWebToken.sign(user, app.get("jwt-secret"), {});
    response.send({ token });
  });
});

app.get("/protected_skills", validateToken, (request, response) => {
  response.send({
    skills: {
      web: ["ReactJS", "Node.js", "Javascript"],
      mobile: ["Android", "ReactNative"]
    }
  });
});

const server = app.listen("8080", () => {
  console.log("Server started. Listening on port 8080...");
});
