function countReducer(state = {
  count: 0,
}, action) {
  switch (action.type) {
  case 'INCR':
    return {
        ...state,
        count: state.count + action.payload,
      };

  case 'DECR':
    return {
        ...state,
        count: state.count - action.payload,
      };

  case 'RESET_COUNT':
    return {
        ...state,
        count: 0,
      };

  default:
    return state;
  }
}

export { countReducer };
