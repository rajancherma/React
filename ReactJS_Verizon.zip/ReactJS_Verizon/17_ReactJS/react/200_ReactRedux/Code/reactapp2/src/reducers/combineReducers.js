import { combineReducers } from 'redux';
import { countReducer } from './countReducer';
import { stepReducer } from './stepReducer';

const AllReducers = combineReducers({ stepReducer, countReducer });

export { AllReducers };
