import React from 'react';
import ReactDOM from 'react-dom';
import { BrowserRouter } from 'react-router-dom';
import { createStore, combineReducers } from 'redux';
import { Provider } from 'react-redux';
import { reducer as formReducer } from 'redux-form';
import { composeWithDevTools } from 'redux-devtools-extension';
// import MuiThemeProvider from 'material-ui/styles/MuiThemeProvider';
import App from './App';

const store = createStore(
  combineReducers({ form: formReducer }),
  composeWithDevTools(),
);

ReactDOM.render(
  <Provider store={store}>
    <BrowserRouter>
      {/* <MuiThemeProvider> */}
      <App />
      {/* </MuiThemeProvider> */}
    </BrowserRouter>
  </Provider>,
  document.getElementById('root'),
);
