import React from 'react';
import * as d3 from 'd3';

class D3Component extends React.Component {
  constructor(props) {
    super(props);

    this.handleClick = this.handleClick.bind(this);
  }

  componentDidMount() {
    const sampleSVG = d3
      .select('#viz')
      .append('svg')
      .attr('width', 100)
      .attr('height', 100);

    sampleSVG
      .append('circle')
      .style('stroke', 'gray')
      .style('fill', 'white')
      .attr('r', 40)
      .attr('cx', 50)
      .attr('cy', 50)
      .on('mouseover', function () {
        d3.select(this).style('fill', 'aliceblue');
      })
      .on('mouseout', function () {
        d3.select(this).style('fill', 'white');
      })
      .on('mousedown', function () {
        d3
          .select(this)
          .transition()
          .delay(0)
          .duration(1000)
          .attr('r', 10);
        /* .each('end', function () {
            d3
              .select(this)
              .transition()
              .duration(1000)
              .attr('r', 40);
          }); */
      });
  }

  shouldComponentUpdate(nextProps, nextState) {
    // Take this component out of react's control. I.e. prevent re-rendering
    return false;
  }

  handleClick() {
    // Re-render this component on-demand.
    this.forceUpdate();
  }

  render() {
    return (
      <div>
        <button type="button" onClick={this.handleClick}>
          Force Update
        </button>
        <br />
        <br />
        <div id="viz" />
        <div>{this.props.randomNumber}</div>
      </div>
    );
  }
}

export default D3Component;
