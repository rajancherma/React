import axios from "axios";

const doAuth = {
  isAuthenticated: localStorage.getItem("jwToken") ? true : false,
  authenticate(username, password, cb) {
    const data = JSON.stringify({
      username: username,
      password: password
    });
    console.log("username: ", username);
    console.log("password: ", password);
    console.log("data: ", data);

    axios
      .post("http://localhost:8080/authenticate", data, {
        headers: {
          "Content-Type": "application/json"
        }
      })
      .then(response => {
        console.log("axios response: ", response);

        //Add jwt token to storage
        localStorage.setItem("jwToken", response.data.token);
        this.isAuthenticated = true;
        cb();
      })
      .catch(error => {
        console.log("axios error.response: ", error.response);
        this.isAuthenticated = false;
        cb(error);
      });
  },
  signout(cb) {
    //Remove jwt token from storage
    localStorage.removeItem("jwToken");

    this.isAuthenticated = false;
    setTimeout(cb, 100);
  }
};

export default doAuth;
