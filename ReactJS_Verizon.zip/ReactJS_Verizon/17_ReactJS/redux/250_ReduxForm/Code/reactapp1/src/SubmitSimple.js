import { SubmissionError } from 'redux-form';

const sleep = ms => new Promise(resolve => setTimeout(resolve, ms));

function submitSimple(values) {
  return sleep(1000).then(() => {
    // simulate server latency
    if (['sreekanth', 'john'].includes(values.username)) {
      throw new SubmissionError({
        username: 'Username not unique!',
        _error: 'This Username has been taken. Choose a different one!',
      });
    } else {
      window.alert(`You submitted:\n\n${JSON.stringify(values, null, 2)}`);
    }
  });
}

export default submitSimple;
