import React from 'react';
import * as d3 from 'd3';

class D3Component extends React.Component {
  constructor(props) {
    super(props);

    this.handleClick = this.handleClick.bind(this);
  }

  componentDidMount() {
    const dataset = [];
    let tmpDataset = [];
    let i;
    let j;

    for (i = 0; i < 5; i += 1) {
      for (j = 0, tmpDataset = []; j < 3; j += 1) {
        tmpDataset.push('Row:' + i + ',Col:' + j);
      }
      dataset.push(tmpDataset);
    }

    d3
      .select('#viz')
      .append('table')
      .style('border-collapse', 'collapse')
      .style('border', '2px black solid')
      .selectAll('tr')
      .data(dataset)
      .enter()
      .append('tr')
      .selectAll('td')
      .data(d => d)
      .enter()
      .append('td')
      .style('border', '1px black solid')
      .style('padding', '10px')
      .on('mouseover', function () {
        d3.select(this).style('background-color', 'aliceblue');
      })
      .on('mouseout', function () {
        d3.select(this).style('background-color', 'white');
      })
      .text(d => d)
      .style('font-size', '12px');
  }

  shouldComponentUpdate(nextProps, nextState) {
    // Take this component out of react's control. I.e. prevent re-rendering
    return false;
  }

  handleClick() {
    // Re-render this component on-demand.
    this.forceUpdate();
  }

  render() {
    return (
      <div>
        <button type="button" onClick={this.handleClick}>
          Force Update
        </button>
        <br />
        <br />
        <div id="viz" />
        <div>{this.props.randomNumber}</div>
      </div>
    );
  }
}

export default D3Component;
