import React from 'react';
import { Switch, Link, Route } from 'react-router-dom';
import SimpleForm from './SimpleForm';
// import FormFields from './FormFields';
// import MaterialUiForm from './MaterialUIForm';

const App = () => (
  <div>
    <ul>
      <li>
        <Link to="/simple">Simple Form</Link>
      </li>

      {/*
      <li>
        <Link to="/formfields">Form Fields</Link>
      </li>
      <li>
        <Link to="/full">MaterialUI Form</Link>
      </li>
      */}
    </ul>

    <Switch>
      <Route path="/simple" component={SimpleForm} />
      {/*
      <Route path="/formfields" component={FormFields} />
       <Route path="/full" component={MaterialUiForm} />
       */}
    </Switch>
  </div>
);

export default App;
