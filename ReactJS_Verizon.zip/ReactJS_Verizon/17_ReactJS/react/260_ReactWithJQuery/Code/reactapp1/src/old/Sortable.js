import React from 'react';
import $ from 'jquery';
import 'jquery-ui/ui/widgets/sortable';
import PropTypes from 'prop-types';
/**
 * An example how to use Jquery UI Sortable with React JS!
*/
class Sortable extends React.Component {
  componentDidMount() {
    // Get the DOM node and store the jQuery element reference
    // this.$node = $(this.refs.sortable);
    // this.$node = $(this.sortableUL);
    // this.$node = $('#sortURL');

    // Initialize the jQuery UI Sortable functionality: https://jqueryui.com/sortable/
    $('#sortUL').sortable({
      // Get the incoming `opacity` prop and use it in the plugin configuration
      opacity: this.props.opacity,
      // Get the incoming onChange func and we invoke it on the Sortable `change` event
      change: (event, ui) => this.props.onChange(event, ui),
    });
  }

  componentWillReceiveProps(nextProps) {
    if (nextProps.enable !== this.props.enable) {
      $('#sortUL').sortable(nextProps.enable ? 'enable' : 'disable');
    }
  }

  // Force a single-render of the component,
  // This way, ReactJS will never re-render our component,
  // and jQuery will be responsible for all updates.
  shouldComponentUpdate() {
    console.log('shouldComponentUpdate() is invoked');
    return true;
  }

  componentWillUnmount() {
    // Clean up the mess when the component unmounts
    $('#sortUL').sortable('destroy');
  }

  // jQuery UI sortable expects a <ul> list with <li>s.
  renderItems() {
    return this.props.data.map((item, i) => (
      <li key={i} className="ui-state-default">
        <span className="ui-icon ui-icon-arrowthick-2-n-s" />
        {item}
      </li>
    ));
  }
  render() {
    return <ul id="sortUL">{this.renderItems()}</ul>;
  }
}

// Optional: set the default props, in case none are passed
Sortable.defaultProps = { opacity: 1, enable: true };

// Optional: set the prop types
Sortable.propTypes = {
  opacity: PropTypes.number,
  enable: PropTypes.bool,
  onChange: PropTypes.func.isRequired,
};

export default Sortable;
